--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2
-- Dumped by pg_dump version 15.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE chinook;
--
-- Name: chinook; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE chinook WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Spanish_Argentina.1252';


ALTER DATABASE chinook OWNER TO postgres;

\connect chinook

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: album; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.album (
    album_id integer NOT NULL,
    title character varying(160) NOT NULL,
    artist_id integer NOT NULL
);


ALTER TABLE public.album OWNER TO postgres;

--
-- Name: artist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.artist (
    artist_id integer NOT NULL,
    name character varying(120)
);


ALTER TABLE public.artist OWNER TO postgres;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    customer_id integer NOT NULL,
    first_name character varying(40) NOT NULL,
    last_name character varying(20) NOT NULL,
    company character varying(80),
    address character varying(70),
    city character varying(40),
    state character varying(40),
    country character varying(40),
    postal_code character varying(10),
    phone character varying(24),
    fax character varying(24),
    email character varying(60) NOT NULL,
    support_rep_id integer
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee (
    employee_id integer NOT NULL,
    last_name character varying(20) NOT NULL,
    first_name character varying(20) NOT NULL,
    title character varying(30),
    reports_to integer,
    birth_date timestamp without time zone,
    hire_date timestamp without time zone,
    address character varying(70),
    city character varying(40),
    state character varying(40),
    country character varying(40),
    postal_code character varying(10),
    phone character varying(24),
    fax character varying(24),
    email character varying(60)
);


ALTER TABLE public.employee OWNER TO postgres;

--
-- Name: genre; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.genre (
    genre_id integer NOT NULL,
    name character varying(120)
);


ALTER TABLE public.genre OWNER TO postgres;

--
-- Name: invoice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoice (
    invoice_id integer NOT NULL,
    customer_id integer NOT NULL,
    invoice_date timestamp without time zone NOT NULL,
    billing_address character varying(70),
    billing_city character varying(40),
    billing_state character varying(40),
    billing_country character varying(40),
    billing_postal_code character varying(10),
    total numeric(10,2) NOT NULL
);


ALTER TABLE public.invoice OWNER TO postgres;

--
-- Name: invoice_line; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoice_line (
    invoice_line_id integer NOT NULL,
    invoice_id integer NOT NULL,
    track_id integer NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    quantity integer NOT NULL
);


ALTER TABLE public.invoice_line OWNER TO postgres;

--
-- Name: media_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.media_type (
    media_type_id integer NOT NULL,
    name character varying(120)
);


ALTER TABLE public.media_type OWNER TO postgres;

--
-- Name: playlist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.playlist (
    playlist_id integer NOT NULL,
    name character varying(120)
);


ALTER TABLE public.playlist OWNER TO postgres;

--
-- Name: playlist_track; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.playlist_track (
    playlist_id integer NOT NULL,
    track_id integer NOT NULL
);


ALTER TABLE public.playlist_track OWNER TO postgres;

--
-- Name: track; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.track (
    track_id integer NOT NULL,
    name character varying(200) NOT NULL,
    album_id integer,
    media_type_id integer NOT NULL,
    genre_id integer,
    composer character varying(220),
    milliseconds integer NOT NULL,
    bytes integer,
    unit_price numeric(10,2) NOT NULL
);


ALTER TABLE public.track OWNER TO postgres;

--
-- Data for Name: album; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.album (album_id, title, artist_id) FROM stdin;
\.
COPY public.album (album_id, title, artist_id) FROM '$$PATH$$/3397.dat';

--
-- Data for Name: artist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.artist (artist_id, name) FROM stdin;
\.
COPY public.artist (artist_id, name) FROM '$$PATH$$/3398.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (customer_id, first_name, last_name, company, address, city, state, country, postal_code, phone, fax, email, support_rep_id) FROM stdin;
\.
COPY public.customer (customer_id, first_name, last_name, company, address, city, state, country, postal_code, phone, fax, email, support_rep_id) FROM '$$PATH$$/3399.dat';

--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee (employee_id, last_name, first_name, title, reports_to, birth_date, hire_date, address, city, state, country, postal_code, phone, fax, email) FROM stdin;
\.
COPY public.employee (employee_id, last_name, first_name, title, reports_to, birth_date, hire_date, address, city, state, country, postal_code, phone, fax, email) FROM '$$PATH$$/3400.dat';

--
-- Data for Name: genre; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.genre (genre_id, name) FROM stdin;
\.
COPY public.genre (genre_id, name) FROM '$$PATH$$/3401.dat';

--
-- Data for Name: invoice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoice (invoice_id, customer_id, invoice_date, billing_address, billing_city, billing_state, billing_country, billing_postal_code, total) FROM stdin;
\.
COPY public.invoice (invoice_id, customer_id, invoice_date, billing_address, billing_city, billing_state, billing_country, billing_postal_code, total) FROM '$$PATH$$/3402.dat';

--
-- Data for Name: invoice_line; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoice_line (invoice_line_id, invoice_id, track_id, unit_price, quantity) FROM stdin;
\.
COPY public.invoice_line (invoice_line_id, invoice_id, track_id, unit_price, quantity) FROM '$$PATH$$/3403.dat';

--
-- Data for Name: media_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.media_type (media_type_id, name) FROM stdin;
\.
COPY public.media_type (media_type_id, name) FROM '$$PATH$$/3404.dat';

--
-- Data for Name: playlist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.playlist (playlist_id, name) FROM stdin;
\.
COPY public.playlist (playlist_id, name) FROM '$$PATH$$/3405.dat';

--
-- Data for Name: playlist_track; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.playlist_track (playlist_id, track_id) FROM stdin;
\.
COPY public.playlist_track (playlist_id, track_id) FROM '$$PATH$$/3406.dat';

--
-- Data for Name: track; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.track (track_id, name, album_id, media_type_id, genre_id, composer, milliseconds, bytes, unit_price) FROM stdin;
\.
COPY public.track (track_id, name, album_id, media_type_id, genre_id, composer, milliseconds, bytes, unit_price) FROM '$$PATH$$/3407.dat';

--
-- Name: album PK_Album; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.album
    ADD CONSTRAINT "PK_Album" PRIMARY KEY (album_id);


--
-- Name: artist PK_Artist; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.artist
    ADD CONSTRAINT "PK_Artist" PRIMARY KEY (artist_id);


--
-- Name: customer PK_Customer; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT "PK_Customer" PRIMARY KEY (customer_id);


--
-- Name: employee PK_Employee; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT "PK_Employee" PRIMARY KEY (employee_id);


--
-- Name: genre PK_Genre; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.genre
    ADD CONSTRAINT "PK_Genre" PRIMARY KEY (genre_id);


--
-- Name: invoice PK_Invoice; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice
    ADD CONSTRAINT "PK_Invoice" PRIMARY KEY (invoice_id);


--
-- Name: invoice_line PK_InvoiceLine; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_line
    ADD CONSTRAINT "PK_InvoiceLine" PRIMARY KEY (invoice_line_id);


--
-- Name: media_type PK_MediaType; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media_type
    ADD CONSTRAINT "PK_MediaType" PRIMARY KEY (media_type_id);


--
-- Name: playlist PK_Playlist; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlist
    ADD CONSTRAINT "PK_Playlist" PRIMARY KEY (playlist_id);


--
-- Name: playlist_track PK_PlaylistTrack; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlist_track
    ADD CONSTRAINT "PK_PlaylistTrack" PRIMARY KEY (playlist_id, track_id);


--
-- Name: track PK_Track; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.track
    ADD CONSTRAINT "PK_Track" PRIMARY KEY (track_id);


--
-- Name: IFK_AlbumArtistId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IFK_AlbumArtistId" ON public.album USING btree (artist_id);


--
-- Name: IFK_CustomerSupportRepId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IFK_CustomerSupportRepId" ON public.customer USING btree (support_rep_id);


--
-- Name: IFK_EmployeeReportsTo; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IFK_EmployeeReportsTo" ON public.employee USING btree (reports_to);


--
-- Name: IFK_InvoiceCustomerId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IFK_InvoiceCustomerId" ON public.invoice USING btree (customer_id);


--
-- Name: IFK_InvoiceLineInvoiceId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IFK_InvoiceLineInvoiceId" ON public.invoice_line USING btree (invoice_id);


--
-- Name: IFK_InvoiceLineTrackId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IFK_InvoiceLineTrackId" ON public.invoice_line USING btree (track_id);


--
-- Name: IFK_PlaylistTrackTrackId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IFK_PlaylistTrackTrackId" ON public.playlist_track USING btree (track_id);


--
-- Name: IFK_TrackAlbumId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IFK_TrackAlbumId" ON public.track USING btree (album_id);


--
-- Name: IFK_TrackGenreId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IFK_TrackGenreId" ON public.track USING btree (genre_id);


--
-- Name: IFK_TrackMediaTypeId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IFK_TrackMediaTypeId" ON public.track USING btree (media_type_id);


--
-- Name: album FK_AlbumArtistId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.album
    ADD CONSTRAINT "FK_AlbumArtistId" FOREIGN KEY (artist_id) REFERENCES public.artist(artist_id);


--
-- Name: customer FK_CustomerSupportRepId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT "FK_CustomerSupportRepId" FOREIGN KEY (support_rep_id) REFERENCES public.employee(employee_id);


--
-- Name: employee FK_EmployeeReportsTo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT "FK_EmployeeReportsTo" FOREIGN KEY (reports_to) REFERENCES public.employee(employee_id);


--
-- Name: invoice FK_InvoiceCustomerId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice
    ADD CONSTRAINT "FK_InvoiceCustomerId" FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id);


--
-- Name: invoice_line FK_InvoiceLineInvoiceId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_line
    ADD CONSTRAINT "FK_InvoiceLineInvoiceId" FOREIGN KEY (invoice_id) REFERENCES public.invoice(invoice_id);


--
-- Name: invoice_line FK_InvoiceLineTrackId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_line
    ADD CONSTRAINT "FK_InvoiceLineTrackId" FOREIGN KEY (track_id) REFERENCES public.track(track_id);


--
-- Name: playlist_track FK_PlaylistTrackPlaylistId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlist_track
    ADD CONSTRAINT "FK_PlaylistTrackPlaylistId" FOREIGN KEY (playlist_id) REFERENCES public.playlist(playlist_id);


--
-- Name: playlist_track FK_PlaylistTrackTrackId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlist_track
    ADD CONSTRAINT "FK_PlaylistTrackTrackId" FOREIGN KEY (track_id) REFERENCES public.track(track_id);


--
-- Name: track FK_TrackAlbumId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.track
    ADD CONSTRAINT "FK_TrackAlbumId" FOREIGN KEY (album_id) REFERENCES public.album(album_id);


--
-- Name: track FK_TrackGenreId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.track
    ADD CONSTRAINT "FK_TrackGenreId" FOREIGN KEY (genre_id) REFERENCES public.genre(genre_id);


--
-- Name: track FK_TrackMediaTypeId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.track
    ADD CONSTRAINT "FK_TrackMediaTypeId" FOREIGN KEY (media_type_id) REFERENCES public.media_type(media_type_id);


--
-- PostgreSQL database dump complete
--

